import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const NaverCallback = () => {
  const navigate = useNavigate();

  useEffect(() => {
    const token = new URLSearchParams(window.location.hash).get('access_token');
    if (token) {
      // 여기에 토큰을 이용해 사용자 정보를 가져오는 코드를 추가합니다.
      console.log('Access Token:', token);

      // 예시: 로컬 스토리지에 토큰 저장
      localStorage.setItem('naver_access_token', token);

      // 메인 페이지로 이동
      navigate('/');
    }
  }, [navigate]);

  return (
    <div>
      <h2>로그인 처리 중...</h2>
    </div>
  );
};

export default NaverCallback;
