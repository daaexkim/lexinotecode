import React from 'react';

const NaverLogin = () => {
  const CLIENT_ID = '3Ql2zk1RbsM0fnhbnXKV';
  const REDIRECT_URI = 'http://localhost:3000/naver/callback'; // 로그인 후 리다이렉트될 URI

  const handleLogin = () => {
    const naverLoginUrl = `https://nid.naver.com/oauth2.0/authorize?response_type=token&client_id=${CLIENT_ID}&redirect_uri=${encodeURIComponent(REDIRECT_URI)}&state=${STATE_STRING}`;
    window.location.href = naverLoginUrl; // 현재 창에서 리디렉션
  };

  return (
    <div>
      <button onClick={handleLogin}>Naver Login</button>
    </div>
  );
};

export default NaverLogin;